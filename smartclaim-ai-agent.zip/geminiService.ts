
import { GoogleGenAI, Type, GenerateContentResponse, Modality } from "@google/genai";
import { ClaimState, ClaimStatus, PolicyTerm, DocumentAnalysis } from "./types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_PROMPT = `You are a Senior Insurance Claim AI Adjuster. 
Your goal is to guide the user through the claim process:
1. REPORTING: Ask for incident time, location, policy number, and description. Identify the incident type (e.g., Medical, Auto, Property).
2. DOCUMENTING: Based on incident type, list required docs. Provide clear examples.
3. VALIDATION & OCR: Analyze uploaded materials. Extract key info (OCR) like dates, amounts, and names. Confirm if they match required types.
4. ASSESSMENT: 
   - First, determine liability based on policy rules. 
   - If not liable, quote the clause.
   - If liable, calculate payout per item (Limits, Deductibles, Special terms).
5. PAYMENT: Confirm banking details and initiate transfer.
   
Current Policy Rules (Mock):
- Auto: Coverage up to $100k, Deductible $500. Not liable if driver was unlicensed.
- Medical: 90% reimbursement, Max $50k. Requires official receipts.
- Property: Max $200k. Not liable for natural wear/tear.

When asking for a location or discussing geography, use Google Maps to provide accurate and up-to-date place information.

Always return helpful, empathetic, but professional responses. Use Chinese for user-facing content.`;

export const getAIResponse = async (
  messages: { role: string; content: string }[],
  state: ClaimState,
  userLocation?: { latitude: number; longitude: number }
) => {
  const ai = getAI();
  // Using gemini-2.5-flash for maps grounding support
  const model = 'gemini-2.5-flash';
  
  const prompt = `
    Current Claim State: ${JSON.stringify(state)}
    History: ${messages.map(m => `${m.role}: ${m.content}`).join('\n')}
    
    Task: Respond to the user's latest message. 
    If you've gathered enough info to change status, indicate it. 
    Always prioritize completing the current step.
    If the user mentions an accident location or you need to find a place, use the Google Maps tool.
  `;

  const config: any = {
    systemInstruction: SYSTEM_PROMPT,
    temperature: 0.7,
    tools: [{ googleMaps: {} }],
  };

  if (userLocation) {
    config.toolConfig = {
      retrievalConfig: {
        latLng: userLocation
      }
    };
  }

  const response = await ai.models.generateContent({
    model,
    contents: [{ parts: [{ text: prompt }] }],
    config,
  });

  const groundingLinks = response.candidates?.[0]?.groundingMetadata?.groundingChunks
    ?.map((chunk: any) => {
      if (chunk.maps) return { uri: chunk.maps.uri, title: chunk.maps.title };
      if (chunk.web) return { uri: chunk.web.uri, title: chunk.web.title };
      return null;
    })
    .filter((link: any) => link !== null);

  return {
    text: response.text || "我暂时无法回答。",
    groundingLinks
  };
};

export const transcribeAudio = async (base64Audio: string): Promise<string> => {
  const ai = getAI();
  const model = 'gemini-3-flash-preview';
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { inlineData: { data: base64Audio, mimeType: 'audio/wav' } },
        { text: "请精准转录这段语音内容，仅返回转录的文本，不要有其他解释。" }
      ]
    }
  });
  return response.text || "";
};

export const fetchPolicyTerms = async (incidentType: string): Promise<PolicyTerm[]> => {
  const ai = getAI();
  const model = 'gemini-3-flash-preview';
  const prompt = `
    Generate a list of 3-4 insurance policy terms and conditions specifically for the incident type: ${incidentType}.
    Each term should have a title and a formal-sounding legal content snippet in Chinese.
    
    Return ONLY JSON array format:
    [
      {
        "id": "term_1",
        "title": "Clause Title",
        "content": "Formal legal description...",
        "category": "Main Category"
      }
    ]
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [{ parts: [{ text: prompt }] }],
    config: {
      responseMimeType: "application/json",
    },
  });

  try {
    return JSON.parse(response.text || '[]');
  } catch (e) {
    console.error("Failed to parse policy terms", e);
    return [];
  }
};

export const analyzeDocument = async (base64: string, mimeType: string, state: ClaimState): Promise<DocumentAnalysis> => {
  const ai = getAI();
  const model = 'gemini-3-flash-preview';
  
  const dischargeSchema = {
    "document_type": "string (Fixed: '出院小结')",
    "document_id": "string",
    "hospital_info": { "hospital_name": "string", "department": "string" },
    "patient_info": { "name": "string", "gender": "string", "age": "integer", "date_of_birth": "string (YYYY-MM-DD)", "nationality": "string", "patient_id": "string" },
    "admission_details": { "admission_date": "string (YYYY-MM-DD HH:MM:SS)", "main_symptoms_on_admission": "string", "admission_condition_summary": "string", "past_medical_history_relevant": "string" },
    "discharge_details": { "discharge_date": "string (YYYY-MM-DD HH:MM:SS)", "hospital_stay_days": "integer", "discharge_status": "string", "discharge_destination": "string" },
    "diagnoses": [{ "diagnosis_name": "string", "diagnosis_type": "string", "icd10_code": "string", "notes": "string" }],
    "hospitalization_course_summary": "string",
    "main_treatments_during_hospitalization": [{ "treatment_name": "string", "description": "string" }],
    "condition_at_discharge": "string",
    "discharge_instructions": {
      "medications": [{ "med_name": "string", "dosage": "string", "frequency": "string", "route": "string", "duration": "string", "notes": "string" }],
      "lifestyle_recommendations": ["string"],
      "follow_up_appointments": [{ "date_or_interval": "string", "department": "string", "notes": "string" }],
      "rehabilitation_advice": ["string"],
      "precautions_and_warnings": ["string"],
      "other_instructions": ["string"]
    },
    "physician_info": { "attending_physician": "string", "resident_physician": "string", "summary_completion_date": "string" },
    "notes": "string"
  };

  const prompt = `
    Perform high-precision OCR and document analysis for this insurance claim material.
    Claim Type: ${state.incidentType}.
    Report Info (Context): ${JSON.stringify(state.reportInfo)}
    
    Tasks:
    1. Identify category in standard Chinese terms (e.g., 身份证, 驾驶证, 行驶证, 医疗发票, 病历本, 出院小结, 医疗费用清单, 诊断证明, 事故现场照片, 车辆受损照片, 银行卡, 维修清单).
       IMPORTANT: Treat "出院记录", "住院小结", "出院证明", "出院证", "discharge summary" ALL as "出院小结".
       IMPORTANT: Treat "医疗费用收据", "住院收费票据" ALL as "医疗发票".

    2. Assess 'clarityScore' (0-100) and 'completenessScore' (0-100).
    3. Check 'isRelevant': Does it match insured name or accident details? Provide 'relevanceReasoning' in Chinese.
    4. Extract key OCR data (date, amount, name, invoiceNumber, merchant).
    5. CRITICAL VALIDATION & DEEP EXTRACTION:
       - If the document is a "Medical Invoice" (医疗发票/医疗收费票据/住院发票/门诊发票):
         You MUST extract detailed medical data following the schema below and return it in the 'medicalData' field.
         Schema for 'medicalData':
         {
           "basicInfo": {
             "admissionDate": "YYYY-MM-DD",
             "age": "string",
             "bedCode": "string",
             "department": "string",
             "dischargeDate": "YYYY-MM-DD",
             "dischargeDiagnosis": "string",
             "gender": "string",
             "hospitalizationNumber": "string",
             "name": "string",
             "otherInfo": "string"
           },
           "chargeItems": [
             {
               "itemName": "string",
               "quantity": number,
               "specifications": "string",
               "totalPrice": number,
               "unitPrice": number
             }
           ],
           "totalAmount": number,
           "insurancePayment": {
             "governmentFundPayment": number,
             "personalPayment": number,
             "personalSelfPayment": number,
             "otherPayment": number,
             "personalAccountPayment": number,
             "personalCashPayment": number
           },
           "invoiceInfo": {
             "invoiceCode": "string",
             "invoiceNumber": "string",
             "verificationCode": "string",
             "issueDate": "YYYY-MM-DD",
             "hospitalName": "string",
             "hospitalType": "string"
           },
           "medicalInsurance": {
             "insuranceType": "string",
             "insuranceNumber": "string",
             "outpatientNumber": "string",
             "visitDate": "YYYY-MM-DD",
             "businessSerialNumber": "string"
           }
         }

       - If the document is a "Discharge Summary" (出院小结 / 出院记录 / 住院小结):
         You MUST extract detailed data following this specific schema structure and return it in the 'dischargeSummaryData' field.
         Schema for 'dischargeSummaryData':
         ${JSON.stringify(dischargeSchema)}
       
       - For 'Invoice' (发票) or 'Receipt' (收据/凭证): Check for 4 mandatory fields: Name (姓名), Date (日期), Amount (金额), and Number (发票号/编号).
       - For 'Medical Record' (病历): Check for 3 mandatory fields: Name (姓名), Date (日期), and Number (病历号/编号). Do NOT check for Amount (金额).
       
       If any mandatory fields for the identified category are missing, add the field name (in Chinese as "姓名", "日期", "金额", or "编号") to the 'missingFields' array.
       
    6. Generate a 'summary' of the document content in 1-2 sentences in Chinese.
    
    Return ONLY JSON format: 
    {
      "category": "string",
      "isRelevant": boolean,
      "relevanceReasoning": "string",
      "clarityScore": number,
      "completenessScore": number,
      "summary": "string",
      "missingFields": ["string"],
      "ocr": {
        "date": "string",
        "amount": number,
        "merchant": "string",
        "name": "string",
        "idNumber": "string",
        "description": "string",
        "invoiceNumber": "string"
      },
      "medicalData": object, // Only if Medical Invoice
      "dischargeSummaryData": object // Only if Discharge Summary
    }
  `;

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { inlineData: { mimeType: mimeType, data: base64 } },
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: "application/json",
    }
  });

  return JSON.parse(response.text || '{}');
};

export const performFinalAssessment = async (state: ClaimState) => {
  const ai = getAI();
  const model = 'gemini-3-pro-preview';
  const prompt = `
    FINAL CLAIM ASSESSMENT REQUEST:
    Claim Type: ${state.incidentType}
    Incident Info: ${JSON.stringify(state.reportInfo)}
    Documents OCR Data: ${JSON.stringify(state.documents.filter(d => d.status === 'verified').map(d => ({ cat: d.category, data: d.ocrData })))}
    
    Calculate compensation based on policy limits and extracted OCR amounts.
    Return JSON format:
    {
      "isLiable": boolean,
      "reasoning": "string",
      "clauseReference": "string",
      "items": [
        {"name": "string", "claimed": number, "approved": number, "deduction": "string"}
      ],
      "totalApproved": number,
      "deductible": number,
      "finalAmount": number
    }
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [{ parts: [{ text: prompt }] }],
    config: {
      responseMimeType: "application/json",
      systemInstruction: SYSTEM_PROMPT,
    }
  });

  return JSON.parse(response.text || '{}');
};

export const connectLive = (callbacks: any) => {
  const ai = getAI();
  return ai.live.connect({
    model: 'gemini-2.5-flash-native-audio-preview-12-2025',
    callbacks,
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
      },
      systemInstruction: SYSTEM_PROMPT + " Now you are interacting via live audio. Be concise but empathetic. Guide the user verbally.",
      inputAudioTranscription: {},
      outputAudioTranscription: {}
    },
  });
};
